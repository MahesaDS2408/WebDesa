<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="msapplication-TileColor" content="#0E0E0E">
    <meta name="template-color" content="#0E0E0E">
    <meta name="msapplication-config" content="browserconfig.xml">
    <meta name="description" content="Index page">
    <meta name="keywords" content="index, page">
    <meta name="author" content="">
    <link rel="shortcut icon" type="image/x-icon" href="assets/imgs/template/faviconpesawaran.png">
    <link href="assets/css/style.css" rel="stylesheet">
    <title>Web Desa Sidodadi</title>
  </head>
  <body>
    <div id="preloader-active">
      <div class="preloader d-flex align-items-center justify-content-center">
        <div class="preloader-inner position-relative">
          <div class="text-center"><img src="assets/imgs/template/loading.gif" alt="Webdesa"></div>
        </div>
      </div>
    </div>
    <header class="header sticky-bar">
      <div class="container">
        <div class="main-header">
          <div class="header-left">
            <div class="header-logo"><a class="d-flex" href="<?php base_url() ?>/"><img alt="Webdesa" src="assets/imgs/template/icondesa.png"></a></div>
          </div>
          <div class="header-nav">
            <nav class="nav-main-menu">
              <ul class="main-menu">
                <!-- <li class="has-children"><a class="active" href="#">Home</a>
                  <ul class="sub-menu">
                    <li><a href="#">Home 1</a></li>
                    <li><a href="#">Home 2</a></li>
                    <li><a href="#">Home 3</a></li>
                  </ul>
                </li>
                <li class="has-children"><a href="companies-grid.html">Info</a>
                  <ul class="sub-menu">
                    <li><a href="#">Info 1</a>
                      <ul class="sub-menu">
                        <li><a href="#">Anak Info 1</a></li>
                        <li><a href="#">Anak Info 2</a></li>
                      </ul>
                    </li>
                    <li><a href="#">Info 2</a></li>
                  </ul>
                </li> -->
                <li><a href="#">Beranda</a></li>
                <li><a href="#">Kontak</a></li>
              </ul>
            </nav>
            <div class="burger-icon burger-icon-white"><span class="burger-icon-top"></span><span class="burger-icon-mid"></span><span class="burger-icon-bottom"></span></div>
          </div>
          <div class="header-right">
            <div class="block-signin">
                <!-- <a class="text-link-bd-btom hover-up" href="#">Daftar</a> -->
                <a class="btn btn-default btn-shadow ml-40 hover-up" href="#">Masuk</a>
            </div>
          </div>
        </div>
      </div>
    </header>
    <div class="mobile-header-active mobile-header-wrapper-style perfect-scrollbar">
      <div class="mobile-header-wrapper-inner">
        <div class="mobile-header-content-area">
          <div class="perfect-scroll">
            <!-- <div class="mobile-search mobile-header-border mb-30">
              <form action="#">
                <input type="text" placeholder="Search…"><i class="fi-rr-search"></i>
              </form>
            </div> -->
            <div class="mobile-menu-wrap mobile-header-border">
              <!-- mobile menu start-->
              <nav>
                <!-- <ul class="mobile-menu font-heading">
                  <li class="has-children"><a class="active" href="#">Home</a>
                    <ul class="sub-menu">
                      <li><a href="#">Home 1</a></li>
                      <li><a href="#">Home 2</a></li>
                      <li><a href="#">Home 3</a></li>
                    </ul>
                  </li>
                  <li class="has-children"><a href="#">Find a Job</a>
                    <ul class="sub-menu">
                      <li><a href="#">Jobs Grid</a></li>
                      <li><a href="#">Jobs List</a></li>
                      <li><a href="#">Jobs Details  </a></li>
                      <li><a href="#">Jobs Details 2 </a></li>
                    </ul>
                  </li> -->
                  <li><a href="#">Beranda</a></li>
                  <li><a href="#">Kontak</a></li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="mobile-header-active mobile-header-wrapper-style perfect-scrollbar">
      <div class="mobile-header-wrapper-inner">
        <div class="mobile-header-content-area">
          <div class="perfect-scroll">
            <!-- <div class="mobile-search mobile-header-border mb-30">
              <form action="#">
                <input type="text" placeholder="Search…"><i class="fi-rr-search"></i>
              </form>
            </div> -->
            <div class="mobile-menu-wrap mobile-header-border">
              <!-- mobile menu start-->
              <nav>
                <ul class="mobile-menu font-heading">
                  <!-- <li class="has-children"><a class="active" href="#">Home</a>
                    <ul class="sub-menu">
                      <li><a href="#">Home 1</a></li>
                      <li><a href="#">Home 2</a></li>
                      <li><a href="#">Home 3</a></li>
                    </ul>
                  </li>
                  <li class="has-children"><a href="#">Find a Job</a>
                    <ul class="sub-menu">
                      <li><a href="#">Jobs Grid</a></li>
                      <li><a href="#">Jobs List</a></li>
                      <li><a href="#">Jobs Details  </a></li>
                      <li><a href="#">Jobs Details 2 </a></li>
                    </ul>
                  </li> -->
                  <li><a href="#">Beranda</a></li>
                  <li><a href="#">Kontak</a></li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
    <main class="main">
        <!-- MAIN KONTEN -->
        <?= $this->renderSection('content'); ?>
        <!-- END MAIN KONTEN --> 
    </main>
    <footer class="footer mt-50">
      <div class="container">
        <div class="footer-bottom mt-50">
          <div class="row">
            <div class="col-md-6"><span class="font-xs color-text-paragraph">Copyright &copy; <?= date('Y') ?>. Webdesa</span></div>
            <div class="col-md-6 text-md-end text-start">
              <div class="footer-social"><a class="font-xs color-text-paragraph" href="#">Privacy Policy</a><a class="font-xs color-text-paragraph mr-30 ml-30" href="#">Terms &amp; Conditions</a><a class="font-xs color-text-paragraph" href="#">Security</a></div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- <script src="assets/js/vendor/jquery-migrate-3.3.0.min.js"></script> -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="assets/js/plugins/waypoints.js"></script>
    <script src="assets/js/plugins/wow.js"></script>
    <script src="assets/js/plugins/magnific-popup.js"></script>
    <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="assets/js/plugins/select2.min.js"></script>
    <script src="assets/js/plugins/isotope.js"></script>
    <script src="assets/js/plugins/scrollup.js"></script>
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- <script src="assets/js/plugins/counterup.js"></script> -->
    <script src="assets/js/main.js?v=1.0"></script>
  </body>
</html>